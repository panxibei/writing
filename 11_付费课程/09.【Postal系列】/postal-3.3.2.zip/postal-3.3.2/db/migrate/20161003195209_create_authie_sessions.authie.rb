# frozen_string_literal: true

# This migration comes from authie (originally 20141012174250)
class CreateAuthieSessions < ActiveRecord::Migration

  def change
  end

end
