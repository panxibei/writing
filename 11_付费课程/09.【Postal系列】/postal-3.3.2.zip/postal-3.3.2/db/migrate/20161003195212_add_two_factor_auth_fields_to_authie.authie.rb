# frozen_string_literal: true

# This migration comes from authie (originally 20150305135400)
class AddTwoFactorAuthFieldsToAuthie < ActiveRecord::Migration

  def change
  end

end
