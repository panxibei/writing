# frozen_string_literal: true

require "migration_waiter"

MigrationWaiter.wait_if_appropriate
