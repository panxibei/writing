# frozen_string_literal: true

# This migration comes from authie (originally 20170417170000)
class AddTokenHashesToAuthieSessions < ActiveRecord::Migration

  def change
  end

end
