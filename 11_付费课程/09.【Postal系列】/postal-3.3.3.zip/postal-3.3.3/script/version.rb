#!/usr/bin/env ruby
# frozen_string_literal: true

require File.expand_path("../lib/postal/version", __dir__)
puts Postal.version
