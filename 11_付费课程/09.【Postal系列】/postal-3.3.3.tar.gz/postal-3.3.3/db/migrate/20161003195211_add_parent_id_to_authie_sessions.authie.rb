# frozen_string_literal: true

# This migration comes from authie (originally 20150109144120)
class AddParentIdToAuthieSessions < ActiveRecord::Migration

  def change
  end

end
