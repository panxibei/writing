# frozen_string_literal: true

# This migration comes from authie (originally 20141013115205)
class AddIndexesToAuthieSessions < ActiveRecord::Migration

  def change
  end

end
