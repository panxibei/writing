# frozen_string_literal: true

require "postal"
