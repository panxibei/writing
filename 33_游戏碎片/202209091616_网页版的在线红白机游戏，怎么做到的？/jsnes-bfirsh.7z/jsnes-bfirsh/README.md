An example app to demonstrate a simple way to embed JSNES.

ROM is by @slembcke: https://github.com/slembcke/InterglacticTransmissing
