VB+SQLite组合，真香演示！

欢迎关注微信公众号：网管小贾

获取更多信息请访问
网管小贾的博客：www.sysadm.cc
