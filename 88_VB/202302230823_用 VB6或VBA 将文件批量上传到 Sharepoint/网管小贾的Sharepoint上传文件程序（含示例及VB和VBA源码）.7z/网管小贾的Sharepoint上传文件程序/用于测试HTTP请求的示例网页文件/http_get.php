<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
</head>
<body>
<p>GET示例</p>
欢迎 <?php

$str = $_GET["myname"];
$encode = mb_detect_encoding($str, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5','LATIN1'));

if($encode != 'UTF-8'){

$result = mb_convert_encoding($result, 'UTF-8', $encode);

} else {
	$result = $str;
}
 // echo $_GET["myname"];
 echo $result;

 ?>!<br>
你的年龄是 <?php echo $_GET["myage"]; ?>  岁。
</body>
</html>