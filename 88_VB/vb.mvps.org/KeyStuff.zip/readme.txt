CDW is a graphical chdir command for console sessions. It was written and
copyrighted by Karl E. Peterson, and the one/only true source for this utility
is: http://vb.mvps.org/tools/files/cdw.zip

To install, copy CDW.EXE to any folder on your system path. If you're not sure
what that means, you probably won't need this utility. <g>  CDW works by stuffing
the keyboard buffer immediately before its process exits. Unfortunately, the
keyboard buffer in Windows 95/98/ME is only 16 characters. So, to use CDW on those
downlevel operating systems, you will need to install KBDBUF.SYS by adding this
line to your CONFIG.SYS file:

   device=c:\dos\drivers\kbdbuf.sys 256
   
Obviously, adjust the path to wherever this file is on your system. If you don't 
have a previous copy of DOS on your system, copy the enclosed KBDBUF.SYS file
to your hard drive, and point to it. Sadly, KBDBUF doesn't seem to work at all
if you have DOSKEY loaded, so you will have to choose.

CDW was written/compiled with VB5. Nearly every system in existence, any more,
has the MSVBVM50.DLL runtime installed. Some really, really old and isolated
Windows 95/98 systems may need this file as well. If so, you may obtain it the
VB5 runtime library here: http://vb.mvps.org/tools/files/msvbvm50.exe



UPDATE (July 2010): The original VB5 compiled version is still available at the 
link shown above.  The EXE included in this sample has been compiled with VB6
though, which is now the more common runtime in widespread distribution.  

