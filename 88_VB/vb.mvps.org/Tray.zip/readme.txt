This sample uses native subclassing, which is available in either VB5 or VB6.  A 
full working sample, and some documentation, is available under the HookXP sample
here: http://vb.mvps.org/samples/HookXP

Also included is a VB4-authored sample that uses the Mabry MsgHook control for
subclassing.  MsgHook may be used with VB5 or VB6, as well, but is no longer
needed unless desired for simplicity.  It is available for download under the Tools
folder: http://vb.mvps.org/tools