These utilities are meant to be run at the command line.  For
more details, please see:

  http://vb.mvps.org/tools/ConClip

They require the VB6/SP5 runtime library.  If you don't have
that installed, the above link will take you to downloads from
both mvps.org and microsoft.com - take yer pick.

=================================================================
=================================================================
=================================================================
C:\>getclip /?

GetClipboard, Version 1.00.0037, http://vb.mvps.org/
Copyright (c)2002-07 Karl E. Peterson, All Rights Reserved

Sends text from Windows clipboard to standard output.

Switches:
   /?       Displays help (this, such as it is)
   /text    Requests plain text from clipboard (default)
   /rtf     Requests RTF from clipboard
   /html    Requests HTML from clipboard
   /frag    Requests HTML Fragment from clipboard
   /enum    Enumerates formats currently on clipboard

Usage examples:
   C:\>GetClip
   C:\>GetClip /html | find "<title>"
   C:\>GetClip > somefile.txt

Exit codes:
   0 = Normal operation
   1 = No text on clipboard
   2 = No RTF on clipboard
   3 = No HTML on clipboard
   4 = Clipboard empty on enumeration

*** FREEWARE ***
=================================================================
=================================================================
=================================================================
C:\>setclip /?


SetClipboard, Version 1.00.0057, http://vb.mvps.org/
Copyright (c)2002-07 Karl E. Peterson, All Rights Reserved

Sends text from StdInput to clipboard.

Switches:
   /?       Displays help (this, such as it is)
   /clear   Clears the clipboard and exits
   /text    Places input on clipboard as plain text (default)
   /rtf     Places input on clipboard as RTF
   /html    Places input on clipboard as HTML
   
   /add     Adds input without first clearing clipboard
   /append  Appends input to clipboard (text only)
   /plain   Clears all clipboard formats except plain text

Notes:
   The /add switch tells SetClip to *not* clear the clipboard before adding
   new input to it.  If the input format already exists on the clipboard, it
   will be overwritten regardless.  This switch is useful if you want to
   preserve existing clipboard data in other formats.

   The /append switch is only available when placing plain text onto the
   clipboard.  When used, existing text on the clipboard remains, and new
   input is appended.  May be used with /add to preserve other formats.
   
   The /plain switch is meant to be used to clean-up the mess left on the
   clipboard by other applications.  This switch simply removes every format
   other than plain text, thus allowing a clean paste into other apps.

Exit codes:
   0        Success
   1        Failure

Usage examples:
   C:\>dir \winnt\system32 | SetClip
   C:\>SetClip < \setuplog.txt
   C:\>type \INetPub\wwwroot\index.htm | SetClip /html
   C:\>SetClip /clear

*** FREEWARE ***
=================================================================
=================================================================
=================================================================
