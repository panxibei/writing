ClipView is a demonstration of various techniques VB5 can use to manipulate data
on the Windows clipboard.  It supports most of the standard formats, and is built
with the idea that as formats for private formats become known support for those
can be readily added in.  If you develop any new format support for ClipView, I
would love to hear about it!  You can email me at <karl@mvps.org>.

Be aware that the enclosed EXE was compiled with VB5/SP3, so if you haven't yet
installed this service pack you'll need to recompile the source in order to try
it.  It also uses native subclassing of the main form, but most of the development
was done using MsgHook.  If you would like to do extensive additions, my
recommendation would be to drop an instance of MsgHook on the main form, uncomment
the MsgHook1_Message routine, and comment out the hooking code in Form_Load and
Form_Unload.

Have Fun!
Karl Peterson