import Steps from './steps.vue';
import Step from './step.vue';

Steps.Step = Step;
export default Steps;