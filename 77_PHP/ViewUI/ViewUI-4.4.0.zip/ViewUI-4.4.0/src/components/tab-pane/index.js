import TabPane from '../tabs/pane.vue';

export default TabPane;