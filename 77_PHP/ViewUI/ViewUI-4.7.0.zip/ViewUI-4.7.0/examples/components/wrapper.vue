<template>
    <div class="i-wrapper"><slot></slot></div>
</template>
<script>
    export default {

    }
</script>