import Header from '../layout/header.vue';

export default Header; 