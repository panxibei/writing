import Page from './page.vue';
export default Page;