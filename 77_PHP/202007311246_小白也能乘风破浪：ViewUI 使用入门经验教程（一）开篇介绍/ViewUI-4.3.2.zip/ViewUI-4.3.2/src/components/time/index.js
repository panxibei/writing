import Time from './time.vue';
export default Time;