import DropdownItem from '../dropdown/dropdown-item.vue';

export default DropdownItem;