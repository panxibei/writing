import Button from './button.vue';
import ButtonGroup from './button-group.vue';

Button.Group = ButtonGroup;
export default Button;