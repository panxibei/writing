import Option from '../select/option.vue';

export default Option;