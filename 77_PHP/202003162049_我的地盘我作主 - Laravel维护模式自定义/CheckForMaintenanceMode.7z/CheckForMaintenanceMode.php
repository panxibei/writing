<?php
/**************************************************************************
 * 代码名称：我的地盘我作主 - Laravel维护模式自定义
 * 描    述：通过自定义数据库字段（消息和特定IP），灵活控制维护时的消息显示及访问IP
 * 模 块 名：CheckForMaintenanceMode
 * 创 建 人：网管小贾 （微信公众号：网管小贾）
 * 日    期：2020-03-16 16:16:16
 * 修 改 人：
 * 版    本：V2003.16.0.1616
 **************************************************************************
 */

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\CheckForMaintenanceMode as Middleware;
use Closure;
use Symfony\Component\HttpFoundation\IpUtils;
use Illuminate\Foundation\Http\Exceptions\MaintenanceModeException;
use Config;

class CheckForMaintenanceMode extends Middleware
{
    /**
     * The URIs that should be reachable while maintenance mode is enabled.
     *
     * @var array
     */
    protected $except = [
        //
    ];

    public function handle($request, Closure $next)
    {
		// 请求前处理内容
        // return $next($request);
        
        // if 就是看 storage/framework/ 下是否存在 down 文件; 有则执行 if 里面的代码
        if ($this->app->isDownForMaintenance()) {

            // 读取维护模式所需的消息及特定IP地址
            $config = Config::where('cfg_name', 'SITE_MAINTENANCE_ALLOWED')
                ->orWhere('cfg_name', 'SITE_MAINTENANCE_MESSAGE')
                ->pluck('cfg_value', 'cfg_name')->toArray();

			// 允许的IP地址，由字符串转成数组形式
			// 如：'127.0.0.1', '10.10.10.10' 转换为 ['127.0.0.1', '10.10.10.10']
            $allowed_ip = explode(',', $config['SITE_MAINTENANCE_ALLOWED']);
            
			// 如果在允许范围内，则正常返回请求
            if (in_array($request->getClientIp(), $allowed_ip)) {
                return $next($request);
            }

            
            // 将 down 文件里面的json数据转换成数组
            $data = json_decode(file_get_contents($this->app->storagePath().'/framework/down'), true);

            // 看一下数组里面的 allowed 与请求过来的 IP 匹配吗，匹配就进入应用
            if (isset($data['allowed']) && IpUtils::checkIp($request->ip(), (array) $data['allowed'])) {
                return $next($request);
            }

            // 这个就是看一下子类定义的除外路由，有没有与请求的路由匹配上，匹配上就进入应用
            if ($this->inExceptArray($request)) {
                return $next($request);
            }



            // 以上条件都不符合，那就祭出维护页面
            if($request->ajax()){
                // 如果是ajax请求，则返回相应信息
				return response()->json();
			} else {
                // 如果有系统维护的自定义消息内容，则显示之
                if (!empty($config['SITE_MAINTENANCE_MESSAGE'])) {
                    $data['message'] = $config['SITE_MAINTENANCE_MESSAGE'];
                }

                // 抛出503
                abort(503, $data['message'] == null || $data['message'] == '' ? '很抱歉，系统维护中！ 请稍后再试！' : $data['message']);
			}

        }
		
		// 如果是正常请求，则直接返回维护页面
        return $next($request);

    }    
}
