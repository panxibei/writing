# Acropadetect

Web tool for detecting Acropalypse (CVE-2023-21036)
