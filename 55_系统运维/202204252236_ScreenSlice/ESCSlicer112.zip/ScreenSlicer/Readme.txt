EIZO ScreenSlicer

Table of Contents 
1) Contents
2) About EIZO ScreenSlicer
   2-1) Referring to User's Manual of EIZO ScreenSlicer
   2-2) Installing EIZO ScreenSlicer

=====================================================================
1) Contents
=====================================================================
- User's Manual
- Software             Version      OS
    EIZO ScreenSlicer  [Ver.1.1.2]  Windows XP SP3
                                    Windows XP Professional x64 Edition SP2
                                    Windows Vista SP2 (32 bit and 64 bit)
                                    Windows 7 SP1 (32 bit and 64 bit)
                                    Windows 8 (32 bit and 64 bit)
- Readmeja.txt file (Japanese)
- Readme.txt file (English)

=====================================================================
2) About EIZO ScreenSlicer
=====================================================================
EIZO ScreenSlicer is the software that divides a screen and lays out 
multiple windows efficiently. 

NOTE
To start EIZO ScreenSlicer, FlexScan LCD monitor is required to be 
connected.

=====================================================================
2-1) Referring to User's Manual of EIZO ScreenSlicer
=====================================================================
Double click "Manual-EN.pdf" in the extracted folder to open the manual.

NOTE
To browse the user's manual of EIZO ScreenSlicer,
Adobe Acrobat Reader 5.0 or later is required.

=====================================================================
2-2) Installing EIZO ScreenSlicer
=====================================================================
(1) Double click "setup.exe" in the extracted folder.
(2) Follow the procedure displayed on the screen.
(3) When the installation is completed, the EIZO ScreenSlicer icon 
    appears on the task bar.


Copyright (C) 2008-2012 EIZO NANAO CORPORATION All rights reserved.
