<?php

/**
 *	just an alias for Subnets
 */

require("Subnets.php");

class Folders_controller extends Subnets_controller {
}
