<?php

/**
 *	just an alias for Vrfs
 */

require("Vrfs.php");

class Vrf_controller extends Vrfs_controller {
}
