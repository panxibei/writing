<?php

/**
 * Script to print devices
 ***************************/

include (dirname(__FILE__)."/../../tools/devices/all-devices.php");
?>

<!-- edit result holder -->
<div class="switchManagementEdit"></div>