<?php
/*
 * insert new hosts to database
 *******************************/

require("subnet-scan-result-scan-icmp.php");
