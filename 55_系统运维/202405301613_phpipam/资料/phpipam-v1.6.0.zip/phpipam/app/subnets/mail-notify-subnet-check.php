<?php

// we use sam script as for sending IP address details

# include required scripts
include( 'addresses/mail-notify-check.php' );

?>