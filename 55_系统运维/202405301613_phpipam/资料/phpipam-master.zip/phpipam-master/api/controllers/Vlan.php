<?php

/**
 *	just an alias for Vlans
 */

require("Vlans.php");

class Vlan_controller extends Vlans_controller {
}
