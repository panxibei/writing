<?php

# include tools rack
include(dirname(__FILE__) . "/../../tools/racks/index.php");