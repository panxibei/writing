<?php
require( dirname(__FILE__) . '/../subnets/subnet-details/subnet-graph.php' );
