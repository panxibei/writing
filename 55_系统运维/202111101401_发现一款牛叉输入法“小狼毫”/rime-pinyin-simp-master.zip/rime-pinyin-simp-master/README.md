# 袖珍简化字拼音

配方： ℞ **pinyin-simp**

[Rime](https://rime.im) 袖珍简化字拼音輸入方案

## 安裝

[東風破](https://github.com/rime/plum) 安裝口令： `bash rime-install pinyin-simp`

授權條款：見 [LICENSE](LICENSE)
