<!--
Please only file issues if you have confirmed the issue is valid for
the latest virt-manager code. Running code from git is pretty easy,
see CONTRIBUTING.md for details.

If you are using distro provided packages and you have not confirmed
the bug exists in this repo, then please file a bug with your distro
instead.

If you are requesting a feature or UI change, please read DESIGN.md
first, especially the section at the end about previously rejected
features.

Thank you!
-->

**Distro**: <!-- FILL ME IN PLEASE -->
