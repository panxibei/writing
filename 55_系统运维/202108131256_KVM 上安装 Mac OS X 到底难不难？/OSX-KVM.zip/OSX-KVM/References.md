### References

* http://www.contrib.andrew.cmu.edu/~somlo/OSXKVM/

* https://www.kraxel.org/blog/2017/09/running-macos-as-guest-in-kvm/

* https://github.com/foxlet/macOS-Simple-KVM
