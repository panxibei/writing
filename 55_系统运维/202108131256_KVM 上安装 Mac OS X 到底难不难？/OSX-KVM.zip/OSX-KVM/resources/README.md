Use `idadif.py` to apply the `kernel.dif` patch to the macOS `kernel` binary.


```
$ sha256sum kernel*
be90edb9653be25e1747cefc1ec9fd452b90dd917ba9eb391a76f260f84cd9f0  kernel <-- patched 10.15.4 kernel
ac2fc51e53519a3147359e2b25dd8aa6b1fa79d41f92091cc058b2aab7e901d6  kernel.bak <-- original 10.15.4 kernel
```
