#### Notes

- Please, DO NOT create a new issue if your issue is already known.
  - Carefully read the documentation included in the repository.
  - Look closely at the closed and open issues.

- Attach details about your host OS (distribution, kernel, QEMU version) and
  host CPU (vendor and model number).

- Remove this template message after reading it ;)
