# nirsoft-bucket
[![update](https://github.com/ScoopInstaller/Nirsoft/actions/workflows/update.yml/badge.svg)](https://github.com/ScoopInstaller/Nirsoft/actions/workflows/update.yml)
<!--
[![Build status](https://ci.appveyor.com/api/projects/status/cdl4l7497plbsyy9?svg=true)](https://ci.appveyor.com/project/MCOfficer/scoop-nirsoft)
-->

A scoop bucket containing almost all of the 280+ programs available at [nirsoft.net](https://www.nirsoft.net/).

[Scoop](https://scoop.sh/) is a windows package manager similar to apt-get or homebrew.
You can add this bucket to scoop using
```
scoop bucket add nirsoft-alternative https://github.com/ScoopInstaller/Nirsoft.git
```
Special thanks to [@MCOfficer](https://github.com/MCOfficer) for developing this bucket!
